package com.EmployeeManagementSystem.Repository;

import com.EmployeeManagementSystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<Employee> findByName(String name);



    @Query("SELECT e FROM Employee e WHERE e.department.name = :departmentName")
    List<Employee> findByDepartmentName(@Param("departmentName") String departmentName);

    // Native SQL query to find employees by partial name match
    @Query(value = "SELECT * FROM Employee e WHERE e.name LIKE %:name%", nativeQuery = true)
    List<Employee> findByNameContaining(@Param("name") String name);

    // Using named query to find employees by department name
    @Query(name = "Employee.findByDepartmentNameNamed")
    List<Employee> findByDepartmentNameNamed(@Param("departmentName") String departmentName);

    // Using named query to find employees by email
    @Query(name = "Employee.findByEmailNamed")
    Employee findByEmailNamed(@Param("email") String email);


}
