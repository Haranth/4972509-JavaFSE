package com.example.EmployeeManagementSystem.dto;

public class EmployeeDTO {
}
package com.example.employeemanagement.dto;

public class EmployeeDTO {
    private String name;
    private String position;
    private String departmentName;

    public EmployeeDTO(String name, String position, String departmentName) {
        this.name = name;
        this.position = position;
        this.departmentName = departmentName;
    }

    // Getters and Setters
}

