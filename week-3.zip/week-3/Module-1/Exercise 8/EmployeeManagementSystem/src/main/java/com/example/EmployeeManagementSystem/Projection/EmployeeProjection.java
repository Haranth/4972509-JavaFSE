package com.example.EmployeeManagementSystem.Projection;

public interface EmployeeProjection {
    String getName();
    String getPosition();
    String getDepartmentName();
}
