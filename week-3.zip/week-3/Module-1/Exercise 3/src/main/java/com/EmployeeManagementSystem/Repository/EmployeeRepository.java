package com.EmployeeManagementSystem.Repository;

import com.EmployeeManagementSystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<Employee> findByName(String name);

    // Derived query method to find employees by department id
    List<Employee> findByDepartmentId(Long departmentId);

    // Derived query method to find employees by email
    Employee findByEmail(String email);


}
