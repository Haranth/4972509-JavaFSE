package com.example.EmployeeManagementSystem.primary.repository;

import com.example.employeemanagement.primary.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
}

