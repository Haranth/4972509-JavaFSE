public class Main {
    public static void main(String[] args) {
        Library library = new Library();

        // Adding Books
        library.addBook(new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"));
        library.addBook(new Book(2, "1984", "George Orwell"));
        library.addBook(new Book(3, "To Kill a Mockingbird", "Harper Lee"));

        // Print all books
        System.out.println("All books:");
        library.printAllBooks();

        // Linear Search
        System.out.println("Linear Search for '1984':");
        Book book1 = library.linearSearchByTitle("1984");
        if (book1 != null) {
            System.out.println("Book found: " + book1);
        } else {
            System.out.println("Book not found.");
        }

        // Sorting books for binary search
        library.sortBooksByTitle();

        // Binary Search
        System.out.println("Binary Search for '1984':");
        Book book2 = library.binarySearchByTitle("1984");
        if (book2 != null) {
            System.out.println("Book found: " + book2);
        } else {
            System.out.println("Book not found.");
        }
    }
}
