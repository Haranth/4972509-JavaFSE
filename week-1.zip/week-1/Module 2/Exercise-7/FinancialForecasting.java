public class FinancialForecasting {
    // Iterative method to calculate future value
    public static double calculateFutureValueIteratively(double presentValue, double annualGrowthRate, int years) {
        double futureValue = presentValue;
        for (int i = 0; i < years; i++) {
            futureValue *= (1 + annualGrowthRate);
        }
        return futureValue;
    }

    public static void main(String[] args) {
        double presentValue = 1000.0; // Initial investment
        double annualGrowthRate = 0.05; // 5% annual growth rate
        int years = 10; // Number of years to predict

        double futureValue = calculateFutureValueIteratively(presentValue, annualGrowthRate, years);
        System.out.println("Future Value after " + years + " years: " + futureValue);
    }
}
