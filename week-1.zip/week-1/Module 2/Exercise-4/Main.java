public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);

        // Adding Employees
        ems.addEmployee(new Employee(1, "Alice", "Manager", 75000));
        ems.addEmployee(new Employee(2, "Bob", "Developer", 60000));
        ems.addEmployee(new Employee(3, "Charlie", "Designer", 55000));

        // Traversing Employees
        System.out.println("Employees:");
        ems.traverseEmployees();

        // Searching for an Employee
        System.out.println("Searching for Employee with ID 2:");
        Employee employee = ems.searchEmployee(2);
        if (employee != null) {
            System.out.println("Employee found: " + employee);
        } else {
            System.out.println("Employee not found.");
        }

        // Deleting an Employee
        System.out.println("Deleting Employee with ID 2:");
        ems.deleteEmployee(2);

        // Traversing Employees after Deletion
        System.out.println("Employees after deletion:");
        ems.traverseEmployees();
    }
}
