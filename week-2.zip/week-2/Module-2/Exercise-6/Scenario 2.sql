--Scenario 2: Apply Annual Fee to All Accounts
DECLARE
    CURSOR cur_accounts IS
        SELECT AccountID, Balance
        FROM Accounts;
BEGIN
    FOR acc IN cur_accounts LOOP
        UPDATE Accounts
        SET Balance = Balance - 100 -- Annual fee amount
        WHERE AccountID = acc.AccountID;
    END LOOP;
    COMMIT;
END;
/
